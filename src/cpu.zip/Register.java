package cpu;

public class Register {
	private int data = 1;
	
	public int get() {return data;}
	public void set(int data) {this.data = data;}
	
	public Register() {
		
	}
}
